import LoginForm from "@/presentation/features/login/components/LoginForm";

export default function loginPage() {
  return <LoginForm />;
}
