import { LayoutProps } from "@/types/next";

export default function AuthLayout({ children }: LayoutProps) {
  return <div>{children}</div>;
}
